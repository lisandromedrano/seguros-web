jpa-templates-TT205
===================

Telosys Tools templates for JPA (TT version 2.0.5) 
